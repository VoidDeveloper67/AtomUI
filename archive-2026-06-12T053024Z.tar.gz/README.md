# Discord Changelog Bot

Bot Discord ringan untuk mem-posting **changelog update** yang rapi dan modern memakai
**Discord Components V2** — kartu full-width, divider native (bukan karakter `─` yang
bisa di-copy), logo game di pojok kanan atas, dan tombol link "Report Bugs" / "Suggest a
Feature".

Cocok buat hub script, project game, atau apa pun yang butuh feed `#changelog` yang enak dilihat.

> Bot ini **standalone** — cuma butuh Node.js + token bot. Tidak ada server/API tambahan,
> tidak ada database eksternal (pakai SQLite lokal otomatis).

---

## Tampilan

```
┌──────────────────────────────────────────────┐
│ # Script Update Logs!                  [logo] │
│ Place: My Game                                │
│ Version: v1.2.0                               │
└──────────────────────────────────────────────┘
┌──────────────────────────────────────────────┐
│ ### Added                                     │
│ [ + ] Auto Farm                               │
│ [ + ] Auto Sell                               │
│ ──────────────  (divider native)  ─────────── │
│ ### Improved                                  │
│ [ ~ ] Better anti-AFK                         │
└──────────────────────────────────────────────┘
[ Report Bugs ]  [ Suggest a Feature ]
```

---

## Yang dibutuhkan

- **Node.js v20 atau lebih baru** (`node -v` untuk cek)
- Sebuah **bot Discord** (token + application id)

---

## Setup (5 langkah)

### 1. Buat bot Discord
1. Buka https://discord.com/developers/applications → **New Application**.
2. Tab **Bot** → **Reset Token** → salin token-nya.
3. Tab **General Information** → salin **Application ID**.
4. Tab **Installation** (atau **OAuth2 → URL Generator**): pilih scope `bot` +
   `applications.commands`, beri permission **Send Messages**, lalu undang bot ke server-mu.

> Tidak perlu mengaktifkan privileged intents apa pun.

### 2. Install dependency
```bash
npm install
```

### 3. Isi konfigurasi
Salin `.env.example` jadi `.env`, lalu isi:
```bash
cp .env.example .env
```
Minimal isi `DISCORD_TOKEN`, `DISCORD_CLIENT_ID`, dan `DISCORD_GUILD_ID`
(ID server tempat ngetes — supaya slash command muncul instan).

### 4. Daftarkan slash command
```bash
npm run deploy-commands
```
Jalankan ini **sekali** (dan tiap kali kamu mengubah definisi command).

### 5. Jalankan bot
```bash
npm start
```
Kalau muncul `[Bot] Logged in as ...`, bot sudah online.

---

## Cara pakai

Tiga slash command (semua hanya untuk **Administrator**):

### `/setchangelogchannel`
Pilih channel tujuan posting changelog.
```
/setchangelogchannel channel:#changelog
```

### `/setgame`
Set logo (thumbnail) per game. Bisa auto-ambil logo dari Roblox lewat GameId, atau pakai URL gambar sendiri.
```
/setgame game:My Game gameid:1234567890        ← auto-fetch logo dari Roblox (universeId)
/setgame game:My Game thumbnail:https://...png  ← pakai URL gambar manual
```
> `gameid` = **universeId** (`game.GameId` di Lua), **bukan** PlaceId. Khusus game Roblox.
> Untuk non-Roblox, pakai opsi `thumbnail`. Nama `game` harus sama dengan yang dipakai di `/changelog`.

### `/changelog`
Posting changelog. Pisahkan beberapa item dengan tanda titik koma `;`.
```
/changelog game:My Game version:v1.2.0
  added:Auto Farm; Auto Sell
  removed:Old teleport
  improved:Better anti-AFK; Faster loading
```
Minimal salah satu dari `added` / `removed` / `improved` harus diisi.

---

## Opsi `.env`

| Variable | Wajib | Fungsi |
|---|---|---|
| `DISCORD_TOKEN` | ✅ | Token bot |
| `DISCORD_CLIENT_ID` | ✅ | Application ID |
| `DISCORD_GUILD_ID` | disarankan | ID server; kalau diisi, command muncul instan. Kosong = global (bisa ~1 jam) |
| `CHANGELOG_CHANNEL_ID` | – | Channel fallback kalau belum pakai `/setchangelogchannel` |
| `ROLE_SUBSCRIBER_ID` | – | Role yang di-ping tiap changelog |
| `PING_EVERYONE` | – | `true` untuk ping `@everyone` tiap post (default off) |
| `BUGREPORT_CHANNEL_URL` | – | URL tombol "Report Bugs" (kosong = tombol disembunyikan) |
| `SUGGESTIONS_CHANNEL_URL` | – | URL tombol "Suggest a Feature" |
| `EMBED_COLOR` | – | Warna garis aksen kiri, hex tanpa `#` (mis. `5865F2`). Kosong = borderless |
| `DB_PATH` | – | Lokasi file SQLite (default `./data/changelog.db`) |

---

## Struktur project

```
discord-changelog-bot/
├── index.js                 # entry point
├── db.js                    # init SQLite (scripts / changelogs / settings)
├── .env.example
├── bot/
│   ├── index.js             # bootstrap bot + loader command
│   ├── deploy-commands.js    # daftarkan slash command
│   ├── lib/
│   │   ├── changelog.js      # renderer Components V2 (jantung tampilannya)
│   │   └── roblox-thumb.js   # auto-fetch logo dari Roblox
│   └── commands/
│       ├── changelog.js
│       ├── setgame.js
│       └── setchangelogchannel.js
```

Mau ubah tampilan? Semua ada di `bot/lib/changelog.js`.

---

## Catatan

- Butuh **discord.js ≥ 14.16** (sudah di `package.json`) karena pakai Components V2.
- Divider antar-section memakai `SeparatorBuilder` native — **tidak bisa di-select/copy**,
  bukan karakter `─`.
- Riwayat changelog tersimpan di tabel `changelogs` (SQLite) kalau nanti mau dibikin halaman arsip.
