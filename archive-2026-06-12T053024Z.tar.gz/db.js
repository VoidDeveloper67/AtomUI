const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dbPath = path.resolve(process.env.DB_PATH || './data/changelog.db');
const dbDir = path.dirname(dbPath);

if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

function initDb() {
  const db = new Database(dbPath);

  // WAL gives better concurrent read/write behaviour and is the recommended mode.
  db.pragma('journal_mode = WAL');

  db.exec(`
    -- Per-game logo used as the top-right thumbnail on each changelog. Managed by /setgame.
    CREATE TABLE IF NOT EXISTS scripts (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      game_name     TEXT NOT NULL UNIQUE,
      thumbnail_url TEXT,
      created_at    INTEGER NOT NULL DEFAULT (unixepoch())
    );

    -- History of every changelog posted (handy if you want to render an archive later).
    CREATE TABLE IF NOT EXISTS changelogs (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      game_name  TEXT NOT NULL,
      version    TEXT NOT NULL,
      added      TEXT,
      removed    TEXT,
      improved   TEXT,
      posted_by  TEXT NOT NULL,
      posted_at  INTEGER NOT NULL DEFAULT (unixepoch())
    );

    -- Generic key/value store. Currently holds the target channel set via /setchangelogchannel.
    CREATE TABLE IF NOT EXISTS settings (
      key   TEXT PRIMARY KEY,
      value TEXT
    );
  `);

  return db;
}

module.exports = { initDb };
