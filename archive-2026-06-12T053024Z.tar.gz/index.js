require('dotenv').config();
const { initDb } = require('./db');
const { startBot } = require('./bot');

async function main() {
  const required = ['DISCORD_TOKEN', 'DISCORD_CLIENT_ID'];
  const missing = required.filter((key) => !process.env[key]);
  if (missing.length > 0) {
    console.error(`[ChangelogBot] Missing environment variables: ${missing.join(', ')}`);
    console.error('[ChangelogBot] Please check your .env file.');
    process.exit(1);
  }

  const db = initDb();
  await startBot(db);
  console.log('[ChangelogBot] Online.');
}

main().catch((err) => {
  console.error('[ChangelogBot] Fatal:', err);
  process.exit(1);
});
