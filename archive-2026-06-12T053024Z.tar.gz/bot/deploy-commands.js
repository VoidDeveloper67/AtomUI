// Registers (or refreshes) the bot's slash commands with Discord.
// Run this once after editing/adding commands:  npm run deploy-commands
require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');

const commands = [];
const commandFiles = fs
  .readdirSync(path.join(__dirname, 'commands'))
  .filter((f) => f.endsWith('.js'));

for (const file of commandFiles) {
  commands.push(require(`./commands/${file}`).data.toJSON());
}

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log(`Registering ${commands.length} command(s)...`);

    if (process.env.DISCORD_GUILD_ID) {
      // Guild-scoped: appears instantly. Best for development.
      await rest.put(
        Routes.applicationGuildCommands(process.env.DISCORD_CLIENT_ID, process.env.DISCORD_GUILD_ID),
        { body: commands }
      );
      console.log('Guild commands registered (instant).');
    } else {
      // Global: can take up to ~1 hour to propagate.
      await rest.put(Routes.applicationCommands(process.env.DISCORD_CLIENT_ID), { body: commands });
      console.log('Global commands registered (may take up to ~1 hour to appear).');
    }
  } catch (err) {
    console.error('Failed to register commands:', err);
  }
})();
