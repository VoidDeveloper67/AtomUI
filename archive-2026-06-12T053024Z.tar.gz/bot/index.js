const { Client, GatewayIntentBits, Collection } = require('discord.js');
const fs = require('fs');
const path = require('path');

async function startBot(db) {
  // Only the Guilds intent is needed to post messages. No privileged intents required,
  // so you don't have to toggle anything extra in the Developer Portal.
  const client = new Client({ intents: [GatewayIntentBits.Guilds] });

  client.db = db;
  client.commands = new Collection();

  const commandFiles = fs
    .readdirSync(path.join(__dirname, 'commands'))
    .filter((f) => f.endsWith('.js'));

  for (const file of commandFiles) {
    const command = require(`./commands/${file}`);
    client.commands.set(command.data.name, command);
  }

  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    try {
      await command.execute(interaction, db);
    } catch (err) {
      console.error(`[Bot] Command error (${interaction.commandName}):`, err);
      const reply = { content: 'An error occurred.', ephemeral: true };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(reply);
      } else {
        await interaction.reply(reply);
      }
    }
  });

  client.once('ready', () => {
    console.log(`[Bot] Logged in as ${client.user.tag}`);
    client.user.setPresence({
      activities: [{ name: 'VoidHub Updates', type: 3 }], // Type 3 is WATCHING
      status: 'dnd',
    });
  });
  client.on('error', (err) => console.error('[Bot] Client error:', err));
  process.on('unhandledRejection', (err) => console.error('[Bot] Unhandled rejection:', err));

  await client.login(process.env.DISCORD_TOKEN);
  return client;
}

module.exports = { startBot };
