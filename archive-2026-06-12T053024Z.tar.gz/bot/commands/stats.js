const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('View bot statistics and total changelogs posted'),

  async execute(interaction, db) {
    const totalChangelogs = db.prepare('SELECT COUNT(*) as count FROM changelogs').get().count;
    const totalGames = db.prepare('SELECT COUNT(*) as count FROM scripts').get().count;
    
    const embed = new EmbedBuilder()
      .setTitle('VoidHub Bot Stats')
      .setColor(0x5865F2)
      .addFields(
        { name: 'Total Changelogs', value: totalChangelogs.toString(), inline: true },
        { name: 'Total Games Tracked', value: totalGames.toString(), inline: true },
        { name: 'Server Count', value: interaction.client.guilds.cache.size.toString(), inline: true }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
