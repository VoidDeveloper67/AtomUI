const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('List all available commands'),

  async execute(interaction) {
    const commands = interaction.client.commands;
    const embed = new EmbedBuilder()
      .setTitle('VoidHub Bot Help')
      .setDescription('Here are the available commands:')
      .setColor(0x5865F2)
      .setTimestamp();

    commands.forEach(cmd => {
      embed.addFields({ name: `/${cmd.data.name}`, value: cmd.data.description });
    });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
