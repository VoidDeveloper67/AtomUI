const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { postChangelogEmbed } = require('../lib/changelog');

// Each change list is a single string; split entries on semicolons.
function parseItems(str) {
  if (!str) return null;
  const items = str.split(';').map((s) => s.trim()).filter(Boolean);
  return items.length ? items : null;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('changelog')
    .setDescription('Post a script update changelog')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((opt) =>
      opt.setName('game').setDescription('Game name (match the one used in /setgame)').setRequired(true)
    )
    .addStringOption((opt) =>
      opt.setName('version').setDescription('Version string, e.g. v1.2.0').setRequired(true)
    )
    .addStringOption((opt) =>
      opt.setName('added').setDescription('New features — separate with semicolons (;)').setRequired(false)
    )
    .addStringOption((opt) =>
      opt.setName('removed').setDescription('Removed features — separate with semicolons (;)').setRequired(false)
    )
    .addStringOption((opt) =>
      opt.setName('improved').setDescription('Improvements — separate with semicolons (;)').setRequired(false)
    ),

  async execute(interaction, db) {
    const game = interaction.options.getString('game');
    const version = interaction.options.getString('version');
    const added = parseItems(interaction.options.getString('added'));
    const removed = parseItems(interaction.options.getString('removed'));
    const improved = parseItems(interaction.options.getString('improved'));

    if (!added && !removed && !improved) {
      return interaction.reply({
        content: 'At least one of: `added`, `removed`, or `improved` is required.',
        ephemeral: true,
      });
    }

    await interaction.deferReply({ ephemeral: true });

    // 1) Save to history.
    const now = Math.floor(Date.now() / 1000);
    let id;
    try {
      const result = db
        .prepare(
          'INSERT INTO changelogs (game_name, version, added, removed, improved, posted_by, posted_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
        )
        .run(
          game,
          version,
          added ? JSON.stringify(added) : null,
          removed ? JSON.stringify(removed) : null,
          improved ? JSON.stringify(improved) : null,
          interaction.user.id,
          now
        );
      id = result.lastInsertRowid;
    } catch (err) {
      console.error('[changelog] insert failed:', err.message);
      return interaction.editReply({ content: 'Failed to save changelog.' });
    }

    // 2) Render + post the message.
    try {
      await postChangelogEmbed(interaction.client, db, {
        id,
        game_name: game,
        version,
        added,
        removed,
        improved,
        posted_at: now,
      });
    } catch (err) {
      console.error('[changelog] post failed:', err);
      return interaction.editReply({ content: `Saved (id ${id}) but failed to post: ${err.message}` });
    }

    await interaction.editReply({ content: `Changelog posted (id: ${id}).` });
  },
};
