const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { fetchGameIcon } = require('../lib/roblox-thumb');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setgame')
    .setDescription('Set or update the changelog thumbnail (logo) for a game')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((opt) =>
      opt.setName('game').setDescription('Game name (use this same name in /changelog)').setRequired(true)
    )
    .addStringOption((opt) =>
      opt
        .setName('gameid')
        .setDescription('Roblox GameId (universeId, NOT PlaceId) — auto-fetches the game logo')
        .setRequired(false)
    )
    .addStringOption((opt) =>
      opt
        .setName('thumbnail')
        .setDescription('Image URL (overrides gameid). Provide this OR gameid.')
        .setRequired(false)
    ),

  async execute(interaction, db) {
    const game = interaction.options.getString('game');
    let thumbnail = interaction.options.getString('thumbnail');
    const gameId = interaction.options.getString('gameid');

    if (!thumbnail && !gameId) {
      return interaction.reply({
        content: 'Provide either `thumbnail` (image URL) or `gameid` (Roblox GameId — universeId, not PlaceId).',
        ephemeral: true,
      });
    }

    await interaction.deferReply({ ephemeral: true });

    // Resolve the URL: an explicit thumbnail wins; otherwise auto-fetch from the GameId.
    let source = 'manual URL';
    if (!thumbnail) {
      if (!/^\d+$/.test(gameId)) {
        return interaction.editReply({ content: '`gameid` must be a numeric Roblox GameId (universeId).' });
      }
      try {
        thumbnail = await fetchGameIcon(gameId);
        source = `GameId ${gameId}`;
      } catch (e) {
        return interaction.editReply({ content: `Failed to fetch icon: ${e.message}` });
      }
    }

    try {
      new URL(thumbnail);
    } catch {
      return interaction.editReply({ content: 'Invalid URL.' });
    }

    // Upsert: update if the game exists, otherwise create the row.
    const result = db.prepare(
      'INSERT INTO scripts (game_name, thumbnail_url) VALUES (?, ?) ' +
      'ON CONFLICT(game_name) DO UPDATE SET thumbnail_url=excluded.thumbnail_url'
    ).run(game, thumbnail);

    const action = result.changes > 0 && result.lastInsertRowid > 0 ? 'added' : 'updated';

    await interaction.editReply({
      content: `Thumbnail ${action} for **${game}** (from ${source}).\n${thumbnail}`,
    });
  },
};
