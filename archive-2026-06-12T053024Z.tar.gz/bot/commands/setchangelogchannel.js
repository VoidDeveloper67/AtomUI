const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setchangelogchannel')
    .setDescription('Choose which channel /changelog posts to')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addChannelOption((opt) =>
      opt
        .setName('channel')
        .setDescription('The channel changelogs will be posted to')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        .setRequired(true)
    ),

  async execute(interaction, db) {
    await interaction.deferReply({ ephemeral: true });

    const channel = interaction.options.getChannel('channel', true);

    // Make sure the bot can actually see the channel before saving it.
    const fetched = await interaction.client.channels.fetch(channel.id).catch(() => null);
    if (!fetched) {
      return interaction.editReply({
        content: `Cannot access <#${channel.id}> — make sure the bot has access to it.`,
      });
    }

    db.prepare(
      "INSERT INTO settings (key, value) VALUES ('changelog_channel', ?) " +
        'ON CONFLICT(key) DO UPDATE SET value=excluded.value'
    ).run(channel.id);

    return interaction.editReply({ content: `Changelog channel set to <#${channel.id}>.` });
  },
};
